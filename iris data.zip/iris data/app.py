from flask import Flask,render_template,request
import numpy as np
import pickle

model = pickle.load(open(r'C:\Users\Anish\anaconda3\envs\dhanya_cs\iris.pkl','rb'))

app = Flask(__name__)


@app.route('/')
def man():
    return render_template('home.html')

@app.route('/predict', methods=['POST'])
def home():
    data1 = request.form['a']
    data2 = request.form['b']
    data3 = request.form['c']
    data4 = request.form['d']
    arry = [[float(data1),float(data2),float(data3),float(data4)]]
    pred = model.predict(arry)
    return render_template('return.html',data=pred)

if __name__ == "__main__":
    app.run(debug=True)
