import numpy as np
import pandas as pd

import pickle

data=pd.read_excel(r'C:\Users\Anish\anaconda3\envs\dhanya_cs\iris.xls')

x=np.array(data.iloc[:, 0:4])
y=np.array(data.iloc[:, 4])  

from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
y = le.fit_transform(y)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test= train_test_split(x,y,random_state=1,test_size=0.2)

from sklearn.linear_model import LogisticRegression
logi_model=LogisticRegression()



sv = logi_model.fit(x_train, y_train)


pickle.dump(sv, open(r'C:\Users\Anish\anaconda3\envs\dhanya_cs\iris.pkl', 'wb'))